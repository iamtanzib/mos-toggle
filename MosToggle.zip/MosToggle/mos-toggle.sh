#!/bin/zsh
# Quit Mos while After Effects / Premiere Pro is frontmost, relaunch otherwise.
# Run by LaunchAgent com.user.mostoggle (hidden, starts at login).
while true; do
  app=$(lsappinfo info -only name "$(lsappinfo front)")
  if [[ $app == *"After Effects"* || $app == *"Premiere Pro"* ]]; then
    pgrep -xq Mos && killall Mos
  else
    pgrep -xq Mos || open -gb com.caldis.Mos
  fi
  sleep 1
done
