#!/bin/zsh
# Stops and removes Mos Toggle.
launchctl bootout gui/$(id -u)/com.user.mostoggle 2>/dev/null
rm -f "$HOME/Library/LaunchAgents/com.user.mostoggle.plist"
rm -rf "$HOME/Library/Application Support/MosToggle"
echo "Mos Toggle removed."
