#!/bin/zsh
# Installs Mos Toggle: hidden background service, starts at login.
set -e
D="$HOME/Library/Application Support/MosToggle"
P="$HOME/Library/LaunchAgents/com.user.mostoggle.plist"
mkdir -p "$D" "$HOME/Library/LaunchAgents"
cp "$(dirname "$0")/mos-toggle.sh" "$D/mos-toggle.sh"
chmod +x "$D/mos-toggle.sh"
cat > "$P" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.user.mostoggle</string>
  <key>ProgramArguments</key><array><string>$D/mos-toggle.sh</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
</dict>
</plist>
PLIST
launchctl bootout gui/$(id -u)/com.user.mostoggle 2>/dev/null || true
launchctl bootstrap gui/$(id -u) "$P"
echo "Mos Toggle installed and running. You can close this window."
